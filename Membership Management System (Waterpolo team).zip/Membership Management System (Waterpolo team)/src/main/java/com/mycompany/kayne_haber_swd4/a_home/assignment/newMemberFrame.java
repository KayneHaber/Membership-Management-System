package com.mycompany.kayne_haber_swd4.a_home.assignment;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class newMemberFrame extends javax.swing.JFrame {
    
    private String fname = "";
    private String surname = "";
    private String gender = "Female";
    private String number = "";
    private String email = "";
    private String position = "";
    private String team = ""; 
    
    private LocalDate endDate;
    private String photoPath;    
    private LocalDate startDate = LocalDate.now();
    private LocalDate DOB;
    
    
    
    
    private void setValues(){
        fname = fnameField.getText();
        surname = surnameField.getText();
        dobField.setText("dd/mm/yyyy");
        DOB = LocalDate.now();
        startDateField.setText(startDate.format(DateTimeFormatter.ofPattern("dd/MM/yyy")));
    }
    
    private void clearForm(){
        fnameField.setText("");
        surnameField.setText("");
        phoneField.setText("");
        emailField.setText("");
        dobField.setText("dd/mm/yyyy");
        startDateField.setText(startDate.format(DateTimeFormatter.ofPattern("dd/MM/yyy")));
        endDateField.setText("");
        teamComboBox.setSelectedIndex(0);
        positionComboBox.setSelectedIndex(0);
        genderRadioBtns.clearSelection();
        passportPhoto.setIcon(null);
        
    }
    
    public static boolean lettersOnly(String s) {
        return s.matches("[a-zA-Z]+");
    }

    public static boolean digitsOnly(String s) {
        return s.matches("\\d+");
    }

    
    private void validateForm(){
        boolean isValid = true;
        
        if(fnameField.getText().isEmpty() || surnameField.getText().isEmpty() || !lettersOnly(fnameField.getText()) || !lettersOnly(surnameField.getText()) ){
            isValid = false;
            JOptionPane.showMessageDialog(null, "Name and Surname can not be left empty and must only contain letters!", "Warning", JOptionPane.WARNING_MESSAGE);
        }
        
        if(!digitsOnly(phoneField.getText()) || phoneField.getText().length() != 8){
            isValid = false;
            JOptionPane.showMessageDialog(null, "Phone Number must only contain digits and has to be 8 digits long!", "Warning",JOptionPane.WARNING_MESSAGE);
        }
        
        if(!emailField.getText().contains("@") || !emailField.getText().contains(".com")){
            isValid = false;
            JOptionPane.showMessageDialog(null, "Invalid email address", "Warning",JOptionPane.WARNING_MESSAGE);
        }

        try {
            String dobText = dobField.getText();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            DOB = LocalDate.parse(dobText, formatter);

            if (DOB.isAfter(LocalDate.now())) {
                isValid = false;
                JOptionPane.showMessageDialog(null, "Date of Birth must be in the past.", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        }  catch (Exception e) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Invalid Date of Birth format. Please use dd/mm/yyyy.", "Warning", JOptionPane.WARNING_MESSAGE);
        }
        
        if(isValid){
            confirmationPopup();
        }
        
    }
    
    private String getSelectedGender() {
        if (maleRadioButton.isSelected()) {
            return "Male";
        } else if (femaleRadioButton.isSelected()) {
            return "Female";
        } else {
            return "";
        }
}
    
    private void confirmationPopup() {
        StringBuilder message = new StringBuilder();
        message.append("Name: ").append(fnameField.getText()).append("\n");
        message.append("Surname: ").append(surnameField.getText()).append("\n");
        message.append("DOB: ").append(dobField.getText()).append("\n");
        message.append("Gender: ").append(getSelectedGender()).append("\n");
        message.append("Phone: ").append(phoneField.getText()).append("\n");
        message.append("Email: ").append(emailField.getText()).append("\n");
        message.append("Position: ").append(positionComboBox.getSelectedItem().toString()).append("\n");
        message.append("Team: ").append(teamComboBox.getSelectedItem().toString()).append("\n");
        message.append("Start Date: ").append(startDateField.getText()).append("\n");
        message.append("End Date: ").append(endDateField.getText()).append("\n");
        message.append("Photo Path: ").append(photoPath != null ? photoPath : "").append("\n");

        int result = JOptionPane.showConfirmDialog(this, message.toString(), "Confirmation", JOptionPane.YES_NO_CANCEL_OPTION);

        if (result == JOptionPane.YES_OPTION) {
            saveToFile();
            clearForm();
        } else if (result == JOptionPane.NO_OPTION) {

        } else {

        }
}

private void saveToFile() {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("playersInfo.txt", true))) {
        writer.write("Name: " + fnameField.getText() + "\n");
        writer.write("Surname: " + surnameField.getText() + "\n");
        writer.write("Team: " + teamComboBox.getSelectedItem().toString() + "\n");
        writer.newLine(); // Separates entries clearly
    } catch (IOException e) {
        e.printStackTrace();
        // Handles the exception as needed
    }
}
        
    /**
     * Creates new form newMemberFrame
     */
    public newMemberFrame() {
        initComponents();
        setValues();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        genderRadioBtns = new javax.swing.ButtonGroup();
        newMemberHeading = new javax.swing.JLabel();
        fnameLabel = new javax.swing.JLabel();
        fnameField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        surnameField = new javax.swing.JTextField();
        dobLabel = new javax.swing.JLabel();
        dobField = new javax.swing.JTextField();
        phoneLabel = new javax.swing.JLabel();
        phoneField = new javax.swing.JTextField();
        emailLabel = new javax.swing.JLabel();
        emailField = new javax.swing.JTextField();
        genderLabel = new javax.swing.JLabel();
        maleRadioButton = new javax.swing.JRadioButton();
        femaleRadioButton = new javax.swing.JRadioButton();
        teamLabel = new javax.swing.JLabel();
        teamComboBox = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        positionComboBox = new javax.swing.JComboBox<>();
        startDateLabel = new javax.swing.JLabel();
        startDateField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        endDateField = new javax.swing.JTextField();
        addPhotoButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        saveButton = new javax.swing.JButton();
        passportPhoto = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        exitButton = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        newMemberButton = new javax.swing.JMenuItem();
        viewMembersButton = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        newMemberHeading.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        newMemberHeading.setText("Add a New Member");

        fnameLabel.setText("Name");

        fnameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fnameFieldActionPerformed(evt);
            }
        });

        jLabel1.setText("Surname");

        surnameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                surnameFieldActionPerformed(evt);
            }
        });

        dobLabel.setText("Date of Birth");

        dobField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dobFieldActionPerformed(evt);
            }
        });

        phoneLabel.setText("Phone");

        phoneField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneFieldActionPerformed(evt);
            }
        });

        emailLabel.setText("Email");

        emailField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailFieldActionPerformed(evt);
            }
        });

        genderLabel.setText("Gender");

        genderRadioBtns.add(maleRadioButton);
        maleRadioButton.setText("Male");
        maleRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maleRadioButtonActionPerformed(evt);
            }
        });

        genderRadioBtns.add(femaleRadioButton);
        femaleRadioButton.setSelected(true);
        femaleRadioButton.setText("Female");

        teamLabel.setText("Team");

        teamComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Development", "U10", "U12", "U14", "U16", "U20", "Senior" }));

        jLabel3.setText("Position");

        positionComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Beginner", "Goalkeeper", "Second Goalkeeper", "1", "2", "3", "4", "5", "6" }));
        positionComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                positionComboBoxActionPerformed(evt);
            }
        });

        startDateLabel.setText("Start Date");

        jLabel2.setText("End Date");

        addPhotoButton.setText("Add Photo");
        addPhotoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addPhotoButtonActionPerformed(evt);
            }
        });

        clearButton.setText("Clear All");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        saveButton.setText("Save");
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });

        jMenu1.setText("File");

        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        jMenu1.add(exitButton);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Members");

        newMemberButton.setText("New Member");
        newMemberButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newMemberButtonActionPerformed(evt);
            }
        });
        jMenu2.add(newMemberButton);

        viewMembersButton.setText("View Members");
        viewMembersButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewMembersButtonActionPerformed(evt);
            }
        });
        jMenu2.add(viewMembersButton);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(fnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1))
                                .addGap(279, 279, 279)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
                                        .addComponent(teamComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(4, 4, 4)
                                        .addComponent(maleRadioButton))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(surnameField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(emailLabel)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(emailField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(phoneLabel)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(phoneField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(dobLabel)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(dobField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(fnameField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(startDateLabel)
                                    .addComponent(teamLabel)
                                    .addComponent(genderLabel)
                                    .addComponent(jLabel2))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(startDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(positionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(endDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(150, 150, 150)
                                .addComponent(addPhotoButton)
                                .addGap(18, 18, 18)
                                .addComponent(clearButton)
                                .addGap(18, 18, 18)
                                .addComponent(saveButton)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(8, 8, 8))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(153, 153, 153)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(femaleRadioButton)
                            .addComponent(newMemberHeading, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(passportPhoto, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(newMemberHeading, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(fnameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fnameLabel)
                            .addComponent(genderLabel)
                            .addComponent(maleRadioButton)
                            .addComponent(femaleRadioButton))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(surnameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(teamLabel)
                            .addComponent(teamComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dobLabel)
                            .addComponent(dobField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(positionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(phoneField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(startDateLabel)
                            .addComponent(startDateField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phoneLabel))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(emailLabel)
                            .addComponent(emailField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(endDateField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(passportPhoto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addPhotoButton)
                    .addComponent(clearButton)
                    .addComponent(saveButton))
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void newMemberButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newMemberButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_newMemberButtonActionPerformed

    
    private void viewMembersButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewMembersButtonActionPerformed
        // TODO add your handling code here:
        // Creates an instance of viewMemberFrame
        viewMembersFrame viewMembersFrm = new viewMembersFrame();
    
        // Make the viewMembersFrame visible
        viewMembersFrm.setVisible(true);
        viewMembersFrm.setLocationRelativeTo(null);
        viewMembersFrm.setResizable(false);
        dispose();
    }//GEN-LAST:event_viewMembersButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void fnameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fnameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fnameFieldActionPerformed

    private void surnameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_surnameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_surnameFieldActionPerformed

    private void dobFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dobFieldActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_dobFieldActionPerformed

    private void phoneFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneFieldActionPerformed

    private void emailFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailFieldActionPerformed

    private void maleRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maleRadioButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_maleRadioButtonActionPerformed

    private void positionComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_positionComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_positionComboBoxActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        // TODO add your handling code here:
        clearForm();
    }//GEN-LAST:event_clearButtonActionPerformed

    private void addPhotoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addPhotoButtonActionPerformed
        // TODO add your handling code here:
        JFileChooser photoChooser = new JFileChooser();
        
        FileNameExtensionFilter fileNameFilter = new FileNameExtensionFilter("Passport Photo", "jpg", "png");
        
        photoChooser.setFileFilter(fileNameFilter);
        
        int isApproved = photoChooser.showOpenDialog(this);
        
        if(isApproved == JFileChooser.APPROVE_OPTION){
            File selectedFile = photoChooser.getSelectedFile();
            photoPath = selectedFile.getAbsolutePath();
            
            try{
                BufferedImage originalImage = ImageIO.read(selectedFile);
                
                int labelWidth = passportPhoto.getWidth();
                int labelHeight = passportPhoto.getHeight();
                Image scaledImage = originalImage.getScaledInstance(labelWidth, labelHeight, Image.SCALE_SMOOTH);
                
                passportPhoto.setIcon(new ImageIcon(scaledImage));
            }
            catch(IOException e){
                System.out.println("Error Reading File");
            }
            
            
        }
        
    }//GEN-LAST:event_addPhotoButtonActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        // TODO add your handling code here:
        validateForm();
    }//GEN-LAST:event_saveButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(newMemberFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(newMemberFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(newMemberFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(newMemberFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new newMemberFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addPhotoButton;
    private javax.swing.JButton clearButton;
    private javax.swing.JTextField dobField;
    private javax.swing.JLabel dobLabel;
    private javax.swing.JTextField emailField;
    private javax.swing.JLabel emailLabel;
    private javax.swing.JTextField endDateField;
    private javax.swing.JMenuItem exitButton;
    private javax.swing.JRadioButton femaleRadioButton;
    private javax.swing.JTextField fnameField;
    private javax.swing.JLabel fnameLabel;
    private javax.swing.JLabel genderLabel;
    private javax.swing.ButtonGroup genderRadioBtns;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JRadioButton maleRadioButton;
    private javax.swing.JMenuItem newMemberButton;
    private javax.swing.JLabel newMemberHeading;
    private javax.swing.JLabel passportPhoto;
    private javax.swing.JTextField phoneField;
    private javax.swing.JLabel phoneLabel;
    private javax.swing.JComboBox<String> positionComboBox;
    private javax.swing.JButton saveButton;
    private javax.swing.JTextField startDateField;
    private javax.swing.JLabel startDateLabel;
    private javax.swing.JTextField surnameField;
    private javax.swing.JComboBox<String> teamComboBox;
    private javax.swing.JLabel teamLabel;
    private javax.swing.JMenuItem viewMembersButton;
    // End of variables declaration//GEN-END:variables
}
