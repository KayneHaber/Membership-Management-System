package com.mycompany.kayne_haber_swd4.a_home.assignment;

public class main {

    public static void main(String[] args) {
        MainFrame mainFrm = new MainFrame();
        mainFrm.setLocationRelativeTo(null);
        mainFrm.setResizable(false);
        mainFrm.setVisible(true);
    }
}
